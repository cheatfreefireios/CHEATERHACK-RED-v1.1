const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Vary': 'Origin'
};
const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { ...CORS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
});
const encoder = new TextEncoder();
const b64url = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
const toHex = bytes => Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, '0')).join('');
const sha256 = async value => toHex(await crypto.subtle.digest('SHA-256', encoder.encode(value)));
const dayKey = () => new Date().toISOString().slice(0, 10);
const randomKey = () => `HR-${toHex(crypto.getRandomValues(new Uint8Array(12))).toUpperCase()}`;
let cachedToken = null;
let tokenExpiry = 0;

async function getAccessToken(env) {
  if (cachedToken && Date.now() < tokenExpiry - 60000) return cachedToken;
  if (!env.FIREBASE_SERVICE_ACCOUNT_JSON) throw new Error('Thiếu FIREBASE_SERVICE_ACCOUNT_JSON trong Worker Secrets.');
  const sa = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT_JSON);
  const now = Math.floor(Date.now() / 1000);
  const header = b64url(encoder.encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const claim = b64url(encoder.encode(JSON.stringify({
    iss: sa.client_email,
    scope: 'https://www.googleapis.com/auth/firebase.database https://www.googleapis.com/auth/userinfo.email',
    aud: 'https://oauth2.googleapis.com/token',
    iat: now,
    exp: now + 3600
  })));
  const unsigned = `${header}.${claim}`;
  const pem = sa.private_key.replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/g, '');
  const binary = Uint8Array.from(atob(pem), c => c.charCodeAt(0));
  const key = await crypto.subtle.importKey('pkcs8', binary, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
  const signature = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, encoder.encode(unsigned));
  const assertion = `${unsigned}.${b64url(signature)}`;
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion })
  });
  const data = await response.json();
  if (!response.ok || !data.access_token) throw new Error('Không lấy được quyền truy cập Firebase: ' + (data.error_description || data.error || response.status));
  cachedToken = data.access_token;
  tokenExpiry = Date.now() + Number(data.expires_in || 3600) * 1000;
  return cachedToken;
}

async function dbRequest(env, path, options = {}) {
  if (!env.FIREBASE_DB_URL) throw new Error('Thiếu FIREBASE_DB_URL trong Worker Variables.');
  const token = await getAccessToken(env);
  const base = env.FIREBASE_DB_URL.replace(/\/$/, '');
  const response = await fetch(`${base}/${path}.json?access_token=${encodeURIComponent(token)}`, options);
  if (!response.ok && response.status !== 412) {
    const detail = await response.text();
    throw new Error(`Firebase trả lỗi ${response.status}: ${detail.slice(0, 250)}`);
  }
  return response;
}

// Tăng bộ đếm bằng ETag/If-Match để tránh hai yêu cầu đồng thời vượt giới hạn.
async function incrementWithinLimit(env, path, limit, errorMessage) {
  for (let attempt = 0; attempt < 8; attempt++) {
    const read = await dbRequest(env, path, { headers: { 'X-Firebase-ETag': 'true' } });
    const current = Number(await read.json() || 0);
    const etag = read.headers.get('ETag');
    if (current >= limit) return { allowed: false, count: current };
    const write = await dbRequest(env, path, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', 'If-Match': etag || 'null' },
      body: JSON.stringify(current + 1)
    });
    if (write.status !== 412) return { allowed: true, count: current + 1 };
  }
  throw new Error('Máy chủ đang bận, vui lòng thử lại.');
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: CORS });
    if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
    const url = new URL(request.url);
    let body;
    try { body = await request.json(); } catch { return json({ error: 'Dữ liệu không hợp lệ.' }, 400); }
    const deviceId = String(body.deviceId || '');
    if (deviceId.length < 8 || deviceId.length > 200) return json({ error: 'Không xác định được thiết bị.' }, 400);
    const ip = request.headers.get('CF-Connecting-IP') || '';
    if (!ip) return json({ error: 'Không xác định được địa chỉ IP.' }, 400);
    const deviceHash = await sha256(deviceId);
    const ipHash = await sha256(ip);
    const today = dayKey();

    try {
      if (url.pathname === '/api/getkey') {
        const deviceCount = await incrementWithinLimit(env, `getkey/daily/device/${today}/${deviceHash}`, 4);
        if (!deviceCount.allowed) return json({ error: 'Đã hết 4 lượt GETKEY hôm nay. Hãy quay lại ngày mai.' }, 429);
        const ipCount = await incrementWithinLimit(env, `getkey/daily/ip/${today}/${ipHash}`, 20);
        if (!ipCount.allowed) return json({ error: 'IP này đã đạt giới hạn 20 lượt GETKEY trong ngày.' }, 429);
        const key = randomKey();
        const now = Date.now();
        const expiresAt = now + 12 * 60 * 60 * 1000;
        await dbRequest(env, `getkey/keys/${await sha256(key)}`, {
          method: 'PUT', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ deviceHash, ipHash, createdAt: now, expiresAt })
        });
        return json({ key, expiresAt, remaining: 4 - deviceCount.count });
      }

      if (url.pathname === '/api/verify') {
        const key = String(body.key || '').trim();
        if (!key) return json({ error: '[ VUI LÒNG NHẬP KEY ]' }, 400);
        const response = await dbRequest(env, `getkey/keys/${await sha256(key)}`);
        const info = await response.json();
        if (!info) return json({ error: '[ KEY KHÔNG TỒN TẠI ]' }, 404);
        if (Date.now() > Number(info.expiresAt)) return json({ error: '[ KEY ĐÃ HẾT HẠN ]' }, 403);
        if (info.deviceHash !== deviceHash) return json({ error: '[ KEY KHÔNG THUỘC THIẾT BỊ NÀY ]' }, 403);
        if (info.ipHash !== ipHash) return json({ error: '[ ĐỊA CHỈ IP KHÔNG KHỚP ]' }, 403);
        return json({ ok: true, expiresAt: info.expiresAt });
      }
      return json({ error: 'Not found' }, 404);
    } catch (error) {
      return json({ error: error.message || 'Lỗi máy chủ.' }, 500);
    }
  }
};
